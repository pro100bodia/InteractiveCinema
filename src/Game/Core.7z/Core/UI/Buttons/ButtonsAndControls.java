package Game.Core.UI.Buttons;

public interface ButtonsAndControls {

    public void onClick();
    public void onFocus();

}
